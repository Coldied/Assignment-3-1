package kz.edu.astanait.Classes;

public interface watch {
    String getModel();
    void setModel(String model);
}
