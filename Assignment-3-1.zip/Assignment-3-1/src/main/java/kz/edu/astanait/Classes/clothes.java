package kz.edu.astanait.Classes;

public class clothes extends Item implements cloth {
    private int quantity = 1;
    private String material;
    private String Brand;
    private String type;
    private int price;
    private int id;
    private String img;

    public clothes(int id, String material, String Brand,String type, int price, String img){
        setId(id);
        setMaterial(material);
        setType(type);
        setBrand(Brand);
        setPrice(price);
        setImage(img);
    }

    @Override
    public int getPrice() {
        return price;
    }

    @Override
    public void setPrice(int price) {
        this.price=price;
    }

    @Override
    public String getBrand() {
        return Brand;
    }

    @Override
    public void setBrand(String brand) {
        this.Brand=brand;
    }

    @Override
    public void setQuantity(int q) {
        this.quantity+=q;
    }

    @Override
    public int getQuantity() {
        return quantity;
    }

    @Override
    public void setImage(String img) {
        this.img = img;
    }

    @Override
    public String getImage() {
        return img;
    }

    @Override
    public void setMaterial(String material) {
        this.material=material;
    }

    @Override
    public String getMaterial() {
        return material;
    }

    @Override
    public void setType(String type) {
        this.type=type;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    public int getId(){
        return id;
    }
}
