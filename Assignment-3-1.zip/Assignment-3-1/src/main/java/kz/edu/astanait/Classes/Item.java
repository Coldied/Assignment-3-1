package kz.edu.astanait.Classes;

public abstract class Item {
    int id;

    public void setId(int id) {
        this.id = id;
    }

    public abstract int getPrice();
    public abstract void setPrice(int price);
    public abstract String getBrand();
    public abstract void setBrand(String brand);
    public abstract void setQuantity(int q);
    public abstract int getQuantity();
    public abstract void setImage(String img);
    public abstract String getImage();

    public abstract int getId();
}
