package kz.edu.astanait.Classes;

public interface cloth {
    void setMaterial(String material);
    String getMaterial();
    void setType(String type);
    String getType();
}
