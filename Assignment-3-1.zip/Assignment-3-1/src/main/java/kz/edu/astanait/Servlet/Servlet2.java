package kz.edu.astanait.Servlet;

import kz.edu.astanait.Classes.Item;
import kz.edu.astanait.Classes.clothes;
import kz.edu.astanait.Classes.watches;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.LinkedList;

@WebServlet(name = "Servlet2")
public class Servlet2 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    LinkedList<Item> list = new LinkedList<>();
    clothes skirt = new clothes(2,"Cotton","Prada","Skirt",666,"https://www.prada.com/content/dam/pradanux_products/P/P16/P160R/1XFRF048W/P160R_1XFR_F048W_S_201_SLF.png");
    clothes shirt = new clothes(1,"Cotton","H&M","Shirt",10,"https://lp2.hm.com/hmgoepprod?set=quality%5B79%5D%2Csource%5B%2F6a%2F91%2F6a91a8bbad9ec1e9facc4491af047f188fe72eab.jpg%5D%2Corigin%5Bdam%5D%2Ccategory%5Bmen_tshirtstanks_shortsleeve%5D%2Ctype%5BDESCRIPTIVESTILLLIFE%5D%2Cres%5Bm%5D%2Chmver%5B1%5D&call=url[file:/product/main]");
    clothes boots = new clothes(3,"Leather","Supreme","Sneakers",385,"https://cdn-images.farfetch-contents.com/15/25/25/05/15252505_26432831_1000.jpg");
    watches pp = new watches(4,"Sport","Patek Philippe",569,"https://cdn.shopify.com/s/files/1/0606/5325/products/Patek_Philippe_Aquanaut_5167A_Tiffany_steel_at_A_Collected_Man_London11.jpg?v=1573673643");
    watches sw = new watches(5,"Classic","Swiss",999,"https://cdn2.chrono24.com/images/uhren/15800673-gqys3z1qy15jbvl1ihd5q22o-Zoom.jpg");
    watches ap = new watches(6,"Smart","Apple",399,"https://fora.kz/images/content/products/611865/casy-apple-watch-series-5-44mm-space-gray-aluminium-case-with-black-sport-band-mwvf2_5d80d6c4b3f86.jpg");

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String s1 = request.getParameter("action");
        String s2 = s1.substring(3,4);
        int s = Integer.parseInt(s2);
        HttpSession session = request.getSession();
        session.setMaxInactiveInterval(60);
        System.out.println(s);
        int quantity = 1;
        if(session.getAttribute("list")==null){
                list.clear();
            if(s==1){
                list.add(shirt);
            }else if(s==2){
                list.add(skirt);
            }
            else if(s==3){
                list.add(boots);
            }
            else if(s==4){
                list.add(pp);
            }
            else if(s==5){
                list.add(sw);
            }
            else{
                list.add(ap);
            }
            System.out.println("Adding first time");
            System.out.println(list.size()+" size of list");
            session.setAttribute("list", list);
        }else{
            int exist = 0;
            for(Item list : list){
                if(list.getId()==s){
                    exist = list.getId();
                }
            }
            if(exist==0){
                if(s==1){
                    list.add(shirt);
                }else if(s==2){
                    list.add(skirt);
                }
                else if(s==3){
                    list.add(boots);
                }
                else if(s==4){
                    list.add(pp);
                }
                else if(s==5){
                    list.add(sw);
                }
                else{
                    list.add(ap);
                }
            }else {
                if(s==1){
                    shirt.setQuantity(quantity);
                }else if(s==2){
                    skirt.setQuantity(quantity);
                }
                else if(s==3){
                    boots.setQuantity(quantity);
                }
                else if(s==4){
                    pp.setQuantity(quantity);
                }
                else if(s==5){
                    sw.setQuantity(quantity);
                }
                else{
                    ap.setQuantity(quantity);
                }
            }
            session.setAttribute("list",list);
            response.sendRedirect(request.getContextPath() +"/cart.jsp");
        }
    }
}
