package kz.edu.astanait.Classes;

public class watches extends Item implements watch {
    private int quantity = 1;
    private int id;
    private String model;
    private String Brand;
    private int price;
    private String img;

    public watches(int id, String model, String Brand, int price, String img){
        setId(id);
        setModel(model);
        setBrand(Brand);
        setPrice(price);
        setImage(img);
    }



    @Override
    public int getPrice() {
        return price;
    }

    @Override
    public void setPrice(int price) {
        this.price=price;
    }

    @Override
    public String getBrand() {
        return Brand;
    }

    @Override
    public void setBrand(String brand) {
        this.Brand=brand;
    }

    @Override
    public void setQuantity(int q) {
        this.quantity+=q;
    }

    @Override
    public int getQuantity() {
        return quantity;
    }

    @Override
    public void setImage(String img) {
        this.img = img;
    }

    @Override
    public String getImage() {
        return img;
    }

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public void setModel(String model) {
        this.model=model;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    public int getId(){
        return id;
    }
}
